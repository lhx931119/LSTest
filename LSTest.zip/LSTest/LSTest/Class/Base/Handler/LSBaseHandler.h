//
//  LSBaseHandler.h
//  LSTest
//
//  Created by 李宏鑫 on 16/11/29.
//  Copyright © 2016年 hongxinli. All rights reserved.
//

#import <Foundation/Foundation.h>

//处理完成事件
typedef void(^CompliteBlock)();

//处理事件成功
typedef void(^SuccessBlock)(id obj);

//处理事件失败
typedef void(^FailureBlock)(NSError *error);


@interface LSBaseHandler : NSObject

@end
