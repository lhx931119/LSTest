//
//  LSTabbarViewController.m
//  LSTest
//
//  Created by 李宏鑫 on 16/11/28.
//  Copyright © 2016年 hongxinli. All rights reserved.
//

#import "LSTabbarViewController.h"
#import "LSBaseNavViewController.h"
#import "LSTabbar.h"
#import "LSLaunchViewController.h"

@interface LSTabbarViewController ()<LSTabbarDelegate>


@property (nonatomic, strong) LSTabbar *customBar;


@property (nonatomic, strong) NSMutableArray *customControllers;
@end

@implementation LSTabbarViewController



//懒加载

- (LSTabbar *)customBar
{

    if (!_customBar) {
        _customBar = [[LSTabbar alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 49)];
        _customBar.delegate = self;
    }
    return _customBar;
}

- (NSMutableArray *)customControllers
{
    if (!_customControllers) {
        _customControllers = [(@[@"LSShowViewController",@"LSMainViewController"]) mutableCopy];
    }
    return _customControllers;

}
- (void)viewDidLoad {
    [super viewDidLoad];
    
       //加载控制器
    [self configViewController];
    
    
    //加载tabbar
    [self.tabBar addSubview:self.customBar];
    
    //消除tabbar的阴影线
    [[UITabBar appearance] setShadowImage:[UIImage new]];
    [[UITabBar appearance] setBackgroundImage:[UIImage new]];


    // Do any additional setup after loading the view.
}


- (void)configViewController
{
    for (int i = 0; i < self.customControllers.count; i++) {
        UIViewController *vc = [[NSClassFromString(self.customControllers[i]) alloc] init];
        
        LSBaseNavViewController *nav = [[LSBaseNavViewController alloc] initWithRootViewController:vc];
        
        [self.customControllers replaceObjectAtIndex:i withObject:nav];
    }
    self.viewControllers = self.customControllers;

}


//delegate  方法
- (void)tabbar:(LSTabbar *)tabbar itemClick:(LStreamType)index
{
    if (index == LStreamType_cammer) {
        
        LSLaunchViewController *vc = [[LSLaunchViewController alloc] init];
        [self presentViewController:vc animated:YES completion:nil];
        
                
    }else {
        self.selectedIndex = index - LStreamType_live;
    }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
} 

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
