//
//  LSTabbar.h
//  LSTest
//
//  Created by 李宏鑫 on 16/11/28.
//  Copyright © 2016年 hongxinli. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSInteger, LStreamType) {

    LStreamType_cammer = 10, //启动
    LStreamType_live = 100,
    LStreamType_show
};

@class LSTabbar;

@protocol LSTabbarDelegate <NSObject>

- (void)tabbar:(LSTabbar *)tabbar itemClick:(LStreamType)index;


@end



@interface LSTabbar : UIView


@property (nonatomic, weak) id<LSTabbarDelegate>delegate;


@end
