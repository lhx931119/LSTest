//
//  LSTabbar.m
//  LSTest
//
//  Created by 李宏鑫 on 16/11/28.
//  Copyright © 2016年 hongxinli. All rights reserved.
//

#import "LSTabbar.h"

@interface LSTabbar ()


@property (nonatomic, strong) NSArray *dataAry;

@property (nonatomic, strong) UIButton *lastItem;

@property (nonatomic, strong) UIButton *camerBtn;

@end



@implementation LSTabbar



//懒加载
- (UIButton *)camerBtn
{
    if (!_camerBtn) {
        _camerBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _camerBtn.tag = LStreamType_cammer;
        [_camerBtn setImage:[UIImage imageNamed:@"tabbar_02.png"] forState:UIControlStateNormal];
        [_camerBtn sizeToFit];
        _camerBtn.center = CGPointMake(self.bounds.size.width / 2, self.bounds.size.height - 40);
        [_camerBtn addTarget:self action:@selector(itemClick:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _camerBtn;
}
- (NSArray *)dataAry
{
    if (!_dataAry) {
        _dataAry = @[@"tabbar_01",@"tabbar_03"];
    }
    return _dataAry;
}
- (instancetype)initWithFrame:(CGRect)frame
{

    self = [super initWithFrame:frame];
    if (self) {
        
        self.backgroundColor = [UIColor whiteColor];
        CGFloat width = SCREEN_WIDTH / self.dataAry.count;
        
        for (int i = 0; i < self.dataAry.count; i++) {
            
            UIButton *item = [UIButton buttonWithType:UIButtonTypeCustom];
            [item setImage:[UIImage imageNamed:[self.dataAry[i] stringByAppendingString:@".png"]] forState:UIControlStateNormal];
            [item setImage:[UIImage imageNamed:[self.dataAry[i] stringByAppendingString:@"_p.png"]] forState:UIControlStateSelected];
            item.frame = CGRectMake(i * width, 0, width, self.frame.size.height);
            
            item.tag = LStreamType_live + i;
            
            if (i == 0) {
                item.selected = YES;
                _lastItem = item;
            }
            [item addTarget:self action:@selector(itemClick:) forControlEvents:UIControlEventTouchUpInside];
            [self addSubview:item];
        }
    
        //添加中间按钮
        [self addSubview:self.camerBtn];
        
    }
    return self;
}



- (void)itemClick:(UIButton *)item
{
    
    
    if (_delegate && [_delegate respondsToSelector:@selector(tabbar:itemClick:)]) {
        [_delegate tabbar:self itemClick:item.tag];
    }

    if (item.tag == LStreamType_cammer) {
        return;
    }
    
    _lastItem.selected = NO;
    item.selected = YES;
    _lastItem = item;
    
    //设置动画
    
    [UIView animateWithDuration:0.2 animations:^{
        item.transform = CGAffineTransformMakeScale(1.2, 1.2);
    } completion:^(BOOL finished) {
        [UIView animateWithDuration:0.2 animations:^{
            //恢复原始状态
            item.transform = CGAffineTransformIdentity;
            
        }];
    }];
    
    

}
@end
