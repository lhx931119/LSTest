//
//  UIView+Layout.h
//  LSTest
//
//  Created by 李宏鑫 on 16/11/29.
//  Copyright © 2016年 hongxinli. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface UIView (Layout)


@property (nonatomic) CGFloat width;

@property (nonatomic) CGFloat height;

@property (nonatomic) CGFloat top;

@property (nonatomic) CGFloat bottom;

@property (nonatomic) CGFloat centerX;

@property (nonatomic) CGFloat centerY;

@property (nonatomic) CGFloat left;

@property (nonatomic) CGFloat right;
@end
