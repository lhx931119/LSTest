//
//  UIImageView+SDWebImage.h
//  LSTest
//
//  Created by 李宏鑫 on 16/11/29.
//  Copyright © 2016年 hongxinli. All rights reserved.
//

#import <UIKit/UIKit.h>


typedef void(^DownLoadImageSuccessBlock)(UIImage *image);
typedef void(^DownLoadImageFailureBlock)(NSError *error);
typedef void(^DownLoadImageProgressBlock)(CGFloat progress);


@interface UIImageView (SDWebImage)


/*
 异步下载图片
 @param   url  图片地址
 @param   imageName  占位图片名
 **/
- (void)downloadImage:(NSString *)url placeholder:(NSString *)imageName;



/*
 异步下载图片
 @param   url  图片地址
 @param   imageName  占位图片名
 @param   success  下载成功
 @param   failure  下载失败
 @param   progress  下载进度

 **/
- (void)downLoadImage:(NSString *)url
          placeholder:(NSString *)imageName
              success:(DownLoadImageSuccessBlock)success
              failure:(DownLoadImageFailureBlock)failure
             progress:(DownLoadImageProgressBlock)progress;



@end
