//
//  UIImageView+SDWebImage.m
//  LSTest
//
//  Created by 李宏鑫 on 16/11/29.
//  Copyright © 2016年 hongxinli. All rights reserved.
//

#import "UIImageView+SDWebImage.h"

#import "UIImageView+WebCache.h"


@implementation UIImageView (SDWebImage)


- (void)downloadImage:(NSString *)url placeholder:(NSString *)imageName
{

    [self sd_setImageWithURL:[NSURL URLWithString:url] placeholderImage:[UIImage imageNamed:imageName] options:SDWebImageRetryFailed | SDWebImageLowPriority];
}

- (void)downLoadImage:(NSString *)url placeholder:(NSString *)imageName success:(DownLoadImageSuccessBlock)success failure:(DownLoadImageFailureBlock)failure progress:(DownLoadImageProgressBlock)progress
{

  
    
    [self sd_setImageWithURL:[NSURL URLWithString:url] placeholderImage:[UIImage imageNamed:imageName]  options:SDWebImageRetryFailed | SDWebImageLowPriority progress:^(NSInteger receivedSize, NSInteger expectedSize, NSURL * _Nullable targetURL) {
        
        progress(receivedSize *1.0 / expectedSize);
        
    } completed:^(UIImage * _Nullable image, NSError * _Nullable error, SDImageCacheType cacheType, NSURL * _Nullable imageURL) {
        
        
        if (error) {
            failure(error);
        }else{
        
            self.image = image;
        }
        
    }];
}
@end
