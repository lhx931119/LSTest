//
//  HttpTools.h
//  LSTest
//
//  Created by 李宏鑫 on 16/11/29.
//  Copyright © 2016年 hongxinli. All rights reserved.
//

#import <Foundation/Foundation.h>


typedef void(^HttpSuccessBlock)(id data);
typedef void(^HttpFailureBlock)(NSError *error);
typedef void(^HttpDownloadProgressBlock)(CGFloat progress);
typedef void(^HttpUploadProgressBlock)(CGFloat progress);
@interface HttpTools : NSObject


/*
 
 get请求
 @param  path   url地址
 @param  params  url参数  NSDictionary类型
 
 @param  success  请求成功返回数据
 @param  failure  请求失败返回错误
 
 **/
+ (void)getWithPath:(NSString *)path
              params:(NSDictionary *)params
            success:(HttpSuccessBlock)success
            failure:(HttpFailureBlock)failure;




/*
 
 post请求
 @param  path   url地址
 @param  params  url参数  NSDictionary类型
 
 @param  success  请求成功返回数据
 @param  failure  请求失败返回错误
 **/

+ (void)postWithPath:(NSString *)path
             params:(NSDictionary *)params
            success:(HttpSuccessBlock)success
            failure:(HttpFailureBlock)failure;

/*

 下载文件
 @param  path   url地址
 @param  success  下载成功
 @param  failure  下载失败
 @param  progress 下载进度
 **/
+ (void)downLoadWithPath:(NSString *)path
             success:(HttpSuccessBlock)success
             failure:(HttpFailureBlock)failure
                progress:(HttpDownloadProgressBlock)progress;


/*
 
 上传图片
 @param  path   url地址
 @param  params  上传参数
 @param  thumbName  imageKey
 @param  image      image对象

 @param  success  上传成功
 @param  failure  上传失败
 @param  progress 上传进度
 
 **/

+ (void)upLoadWithPath:(NSString *)path
                params:(NSDictionary *)params
             thumbName:(NSString *)imageKey
                 image:(UIImage *)image
                 success:(HttpSuccessBlock)success
                 failure:(HttpFailureBlock)failure
                progress:(HttpDownloadProgressBlock)progress;



@end
