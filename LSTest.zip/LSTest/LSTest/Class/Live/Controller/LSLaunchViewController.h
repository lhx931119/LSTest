//
//  LSLaunchViewController.h
//  LSTest
//
//  Created by 李宏鑫 on 16/11/28.
//  Copyright © 2016年 hongxinli. All rights reserved.
//

#import "LSBaseViewController.h"

@interface LSLaunchViewController : LSBaseViewController

@end
