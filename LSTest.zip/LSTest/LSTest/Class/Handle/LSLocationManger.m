//
//  LSLocationManger.m
//  LSTest
//
//  Created by 李宏鑫 on 16/11/30.
//  Copyright © 2016年 hongxinli. All rights reserved.
//

#import "LSLocationManger.h"
#import <CoreLocation/CoreLocation.h>

@interface LSLocationManger ()<CLLocationManagerDelegate>

@property (nonatomic, strong) CLLocationManager *locationManger;

@end


@implementation LSLocationManger



///初始化单例
+ (instancetype)sharedManger
{

    static LSLocationManger *manger = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manger = [[LSLocationManger alloc] init];
    });
    return manger;
}


///重写初始化
- (instancetype)init{

    self = [super init];
    if (self) {
        _locationManger = [[CLLocationManager alloc] init];
        //精确度
        [_locationManger setDesiredAccuracy:kCLLocationAccuracyBest];
        _locationManger.distanceFilter = 100;
        _locationManger.delegate = self;
        
        //判断服务是否开启
        if ([self.locationManger respondsToSelector:@selector(requestWhenInUseAuthorization)]) {
            [self.locationManger requestWhenInUseAuthorization];
        }
    }
    
    return self;
}

- (void)locationManager:(CLLocationManager *)manager
    didUpdateToLocation:(CLLocation *)newLocation
           fromLocation:(CLLocation *)oldLocation
{
    CLLocationCoordinate2D coor = newLocation.coordinate;
    NSString *lat = [@(coor.latitude) description];
    NSString *lon = [@(coor.longitude) description];
    
    [LSLocationManger sharedManger].lat = lat;
    [LSLocationManger sharedManger].lon = lon;
    
    self.locationBlock(lat,lon);
}

- (void)locationManager:(CLLocationManager *)manager
       didFailWithError:(NSError *)error{

    NSLog(@"---%@----", @(error.code));

//    if (error.code == kCLErrorDenied) {
//        NSLog(@"---%@----", @(error.code));
//        
//    }
}

//- (void)locationManager:(CLLocationManager *)manager
//     didUpdateLocations:(NSArray<CLLocation *> *)locations
//{
//    CLLocation *location = [locations lastObject];
//    CLLocationCoordinate2D coor = location.coordinate;
//}

- (void)getGps:(LocationBlock)block
{
    self.locationBlock = block;
    [self.locationManger startUpdatingLocation];

    
}


@end
