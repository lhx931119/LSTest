//
//  LSLocationManger.h
//  LSTest
//
//  Created by 李宏鑫 on 16/11/30.
//  Copyright © 2016年 hongxinli. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void(^LocationBlock)(NSString *lat, NSString *lon);

@interface LSLocationManger : NSObject


@property (nonatomic, copy) LocationBlock locationBlock;

+ (instancetype)sharedManger;

- (void)getGps:(LocationBlock)block;

@property (nonatomic, copy) NSString *lat;
@property (nonatomic, copy) NSString *lon;

@end
