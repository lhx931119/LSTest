//
//  LSLiveHandle.h
//  LSTest
//
//  Created by 李宏鑫 on 16/11/29.
//  Copyright © 2016年 hongxinli. All rights reserved.
//

#import "LSBaseHandler.h"


@interface LSLiveHandle : LSBaseHandler

/*
 获取热门直播信息
 
 @param  success
 @param failure
 
 ****/

///获取热门直播信息
+ (void)executeGetHotLiveTaskWithSuccess:(SuccessBlock)success failure:(FailureBlock)failure;


/*
 获取附近信息
 @param   param     参数
 @param  success
 @param failure
 
 ****/

///获取附近信息
+ (void)executeGetNearLiveTaskWithSuccess:(SuccessBlock)success failure:(FailureBlock)failure;




/*
 获取广告页面信息

 @param  success
 @param failure
 
 ****/
///获取广告页面
+ (void)executeGetAdvertiseImageTaskWithSuccess:(SuccessBlock)success failure:(FailureBlock)failure;


@end
