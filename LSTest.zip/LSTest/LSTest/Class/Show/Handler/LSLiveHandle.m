//
//  LSLiveHandle.m
//  LSTest
//
//  Created by 李宏鑫 on 16/11/29.
//  Copyright © 2016年 hongxinli. All rights reserved.
//

#import "LSLiveHandle.h"
#import "HttpTools.h"
#import "LSLive.h"
#import "LSLocationManger.h"
#import "LSAdvertise.h"

@implementation LSLiveHandle


+ (void)executeGetHotLiveTaskWithSuccess:(SuccessBlock)success failure:(FailureBlock)failure
{
    [HttpTools getWithPath:API_HotLive params:nil success:^(id data) {
        if ([data[@"dm_error"] integerValue]) {
            failure(data[@"error_msg"]);
        }else{
        
            //返回正确 进行数据解析
          NSArray *lives = [LSLive mj_objectArrayWithKeyValuesArray:data[@"lives"]];
            success(lives);

        }
        
        
    } failure:^(NSError *error) {
        failure(error);
    }];
    
}


+ (void)executeGetNearLiveTaskWithSuccess:(SuccessBlock)success failure:(FailureBlock)failure
{
    
    LSLocationManger *manger = [LSLocationManger sharedManger];
    
    NSDictionary *param = @{@"uid":@"85149891",
                            @"latitude":manger.lat,
                            @"longitude":manger.lon
                            };
    
    [HttpTools getWithPath:API_NearLive params:param success:^(id data) {
        
        if ([data[@"dm_error"] integerValue]) {
            failure(data[@"error_msg"]);
        }else{
            
            //返回正确 进行数据解析
            NSArray *lives = [LSLive mj_objectArrayWithKeyValuesArray:data[@"lives"]];
            success(lives);
        }
    } failure:^(NSError *error) {
        failure(error);
    }];
    
}


+ (void)executeGetAdvertiseImageTaskWithSuccess:(SuccessBlock)success failure:(FailureBlock)failure{


    [HttpTools getWithPath:API_Advertise params:nil success:^(id data) {
        
        if ([data[@"dm_error"] integerValue]) {
            failure(data[@"error_msg"]);
        }else{
            
            LSAdvertise *advertise = [LSAdvertise mj_objectWithKeyValues:[data[@"resources"] firstObject]];
            success(advertise);
                
        }

        NSLog(@"----data = %@-----", data);
    } failure:^(NSError *error) {
        NSLog(@"----error = %@-----", error);

    }];
}


@end
