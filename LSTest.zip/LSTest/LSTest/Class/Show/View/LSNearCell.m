//
//  LSNearCell.m
//  LSTest
//
//  Created by 李宏鑫 on 16/11/30.
//  Copyright © 2016年 hongxinli. All rights reserved.
//

#import "LSNearCell.h"


@interface LSNearCell ()
@property (weak, nonatomic) IBOutlet UIImageView *headView;
@property (weak, nonatomic) IBOutlet UILabel *distanceLabel;

@end

@implementation LSNearCell

- (void)showAnimation
{

    if (self.live.isShow) {
        return;
    }
    self.layer.transform = CATransform3DMakeScale(0.1, 0.1, 1);
    [UIView animateWithDuration:0.5 animations:^{
        self.layer.transform = CATransform3DIdentity;
        self.live.show = YES;
    }];
}


- (void)setLive:(LSLive *)live
{

    _live = live;
    
    [self.headView downloadImage:[NSString stringWithFormat:@"%@%@", IMAGE_HOST, live.creator.portrait] placeholder:nil];
    
    self.distanceLabel.text = live.distance;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
