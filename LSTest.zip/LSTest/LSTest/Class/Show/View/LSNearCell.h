//
//  LSNearCell.h
//  LSTest
//
//  Created by 李宏鑫 on 16/11/30.
//  Copyright © 2016年 hongxinli. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "LSLive.h"

@interface LSNearCell : UICollectionViewCell

@property (nonatomic, strong) LSLive *live;

- (void)showAnimation;

@end
