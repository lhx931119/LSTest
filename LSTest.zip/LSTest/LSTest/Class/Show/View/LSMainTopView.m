//
//  LSMainTopView.m
//  LSTest
//
//  Created by 李宏鑫 on 16/11/29.
//  Copyright © 2016年 hongxinli. All rights reserved.
//

#import "LSMainTopView.h"


@interface LSMainTopView ()
@property (nonatomic, strong) UIView *lineView;

@property (nonatomic, strong) NSMutableArray *titleBtns;
@end

@implementation LSMainTopView



- (instancetype)initWithFrame:(CGRect)frame titlesNames:(NSArray *)titleNames
{

    self = [super initWithFrame:frame];
    if (self) {
        CGFloat btnWid = self.frame.size.width / titleNames.count;
        CGFloat btnHei = self.frame.size.height;
        
        for (int i = 0 ; i < titleNames.count; i++) {
            
            UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
//            btn.backgroundColor = [UIColor redColor];
            NSString *titleName = titleNames[i];
            [btn setTitle:titleName forState:UIControlStateNormal];
            
            btn.tag = i;
            //设置文字颜色
            [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            
            //设置字体
            btn.titleLabel.font = [UIFont systemFontOfSize:18];
            
            btn.frame = CGRectMake(i * btnWid, 0, btnWid, btnHei);
            
            [btn addTarget:self action:@selector(titleClick:) forControlEvents:UIControlEventTouchUpInside];
            
            [self.titleBtns addObject:btn];
            [self addSubview:btn];
            
            if (i == 1) {
                
                CGFloat lineH = 2;
                CGFloat lineY = 40 ;

                [btn.titleLabel sizeToFit];
                
                self.lineView = [[UIView alloc] init];
                self.lineView.backgroundColor = [UIColor whiteColor];
                
                
                self.lineView.height = lineH;
                self.lineView.width = btn.titleLabel.width;
                self.lineView.top = lineY;
                self.lineView.centerX = btn.centerX;
                [self addSubview:self.lineView];
                
            }
        }
    }
    return self;
}

//懒加载
- (NSMutableArray *)titleBtns
{

    if (!_titleBtns) {
        _titleBtns = [NSMutableArray array];
    }
    return _titleBtns;
}

//点击事件
- (void)titleClick:(UIButton *)sender
{
    
    if (_block) {
        _block(sender.tag);
    }
    [self scroller:sender.tag];
}

//外界调用
- (void)scroller:(NSInteger)tag
{
    UIButton *btn = self.titleBtns[tag];
    
    
    [UIView animateWithDuration:0.5 animations:^{
        
        self.lineView.centerX = btn.centerX;
        
    }];

    
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
