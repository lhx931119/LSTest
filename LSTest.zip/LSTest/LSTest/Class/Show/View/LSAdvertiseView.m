//
//  LSAdvertiseView.m
//  LSTest
//
//  Created by 李宏鑫 on 16/12/1.
//  Copyright © 2016年 hongxinli. All rights reserved.
//

#import "LSAdvertiseView.h"
#import "LSAdvertise.h"

#import "SDWebImageManager.h"

#import "UILabel+Category.h"


static NSInteger showTime = 3;

@interface LSAdvertiseView ()
@property (weak, nonatomic) IBOutlet UIImageView *backImageView;
@property (weak, nonatomic) IBOutlet UILabel *timeLabel;

@property (nonatomic, strong) dispatch_source_t timer;
@end

@implementation LSAdvertiseView

+ (instancetype)loadAdvertiseView
{

    return [[[NSBundle mainBundle] loadNibNamed:@"LSAdvertiseView" owner:self options:nil] lastObject];
}


//初始化LSAdvertiseViewUI

- (void)awakeFromNib
{

    self.frame = [UIScreen mainScreen].bounds;
    
    //下载
    [self downLoadAdvertise];
    
    //展示
    [self showAdvertise];
    
    //倒计时
    [self timerAdvertise];
}


- (void)showAdvertise{

    NSString *imageUrl = UserDefaultRead(ADVERTISE_IMAGE);
    NSString *imagePath =  PICTURE_PATH(IMAGE_HOST, imageUrl);
    
    UIImage *cacheImage = [[SDWebImageManager sharedManager].imageCache imageFromDiskCacheForKey:imagePath];
    if (cacheImage) {
        self.backImageView.image = cacheImage;
    }else{

        self.backImageView.hidden = YES;
    }
    
    
}

- (void)downLoadAdvertise{
    
    [LSLiveHandle executeGetAdvertiseImageTaskWithSuccess:^(id obj) {
        
        LSAdvertise *advertise = obj;
        
        //SDWebImageAvoidAutoSetImage 下载完后不给image赋值
        [[SDWebImageManager sharedManager] loadImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@", IMAGE_HOST, advertise.image]] options:SDWebImageAvoidAutoSetImage progress:nil completed:^(UIImage * _Nullable image, NSData * _Nullable data, NSError * _Nullable error, SDImageCacheType cacheType, BOOL finished, NSURL * _Nullable imageURL) {
            
            UserDefaultWrite(ADVERTISE_IMAGE, advertise.image);
            UserDefaultSynchronize;
            
        }];
        
    } failure:^(NSError *error) {
            
    }];
}

- (void)timerAdvertise{

   __block NSInteger timeOut = showTime + 1;
    
    
    dispatch_source_t timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, dispatch_get_global_queue(0, 0));
    self.timer = timer;
    
    dispatch_source_set_timer(timer, DISPATCH_TIME_NOW, 1 * NSEC_PER_SEC, 0 * NSEC_PER_SEC);
    
    dispatch_source_set_event_handler(timer, ^{
        if (timeOut <= 0) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [self advertiseDissmiss];
            });
        }else{
        

            dispatch_async(dispatch_get_main_queue(), ^{
                self.timeLabel.text = [NSString stringWithFormat:@"%zd 跳过",timeOut];
                [self.timeLabel text:[NSString stringWithFormat:@"%zd",timeOut] color:[UIColor redColor] font:[UIFont systemFontOfSize:12]];
                [self.timeLabel changeColor];
                
            });
            
            timeOut--;

        }

    });
    dispatch_resume(timer);
}

- (void)advertiseDissmiss{
    
    [UIView animateWithDuration:0.5 animations:^{
        self.alpha = 0;
        
    } completion:^(BOOL finished) {
        [self removeFromSuperview];
    }];
}

@end
