//
//  LSAdvertiseView.h
//  LSTest
//
//  Created by 李宏鑫 on 16/12/1.
//  Copyright © 2016年 hongxinli. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LSAdvertiseView : UIView


+ (instancetype)loadAdvertiseView;


@end
