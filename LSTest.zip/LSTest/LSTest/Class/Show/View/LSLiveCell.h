//
//  LSLiveCell.h
//  LSTest
//
//  Created by 李宏鑫 on 16/11/29.
//  Copyright © 2016年 hongxinli. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "LSLive.h"

@interface LSLiveCell : UITableViewCell

@property (nonatomic, strong) LSLive *live;

@end
