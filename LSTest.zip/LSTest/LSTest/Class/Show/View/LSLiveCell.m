//
//  LSLiveCell.m
//  LSTest
//
//  Created by 李宏鑫 on 16/11/29.
//  Copyright © 2016年 hongxinli. All rights reserved.
//

#import "LSLiveCell.h"

@interface LSLiveCell ()
@property (weak, nonatomic) IBOutlet UIImageView *headView;
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet UILabel *locationLabel;
@property (weak, nonatomic) IBOutlet UILabel *onLineLabel;
@property (weak, nonatomic) IBOutlet UIImageView *backImageView;

@end

@implementation LSLiveCell


- (void)setLive:(LSLive *)live
{

    _live = live;
    
    
    
    [self.headView downloadImage:[NSString stringWithFormat:@"%@%@", IMAGE_HOST, live.creator.portrait] placeholder:@""];
    
    [self.backImageView downloadImage:[NSString stringWithFormat:@"%@%@", IMAGE_HOST, live.creator.portrait] placeholder:@""];
    
    self.nameLabel.text = live.creator.nick;
    
    self.locationLabel.text = live.city;
    
    self.onLineLabel.text = [@(live.onlineUsers) description];

}
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    
//    self.headView.layer.cornerRadius = 25;
//    self.headView.layer.masksToBounds = YES;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
