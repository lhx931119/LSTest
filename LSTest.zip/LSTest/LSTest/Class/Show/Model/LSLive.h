//
//  LSLive.h
//  LSTest
//
//  Created by 李宏鑫 on 16/11/29.
//  Copyright © 2016年 hongxinli. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "LSCreator.h"
@interface LSLive : NSObject


@property (nonatomic, strong) NSString *city;

@property (nonatomic, strong) NSString *image;
@property (nonatomic, strong) NSString *ID;
@property (nonatomic, strong) LSCreator *creator;

@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSString *streamAddr;
@property (nonatomic, strong) NSString *shareAddr;
@property (nonatomic, assign) NSInteger group;
@property (nonatomic, assign) NSInteger link;
@property (nonatomic, assign) NSInteger multi;
@property (nonatomic, assign) NSInteger onlineUsers;
@property (nonatomic, assign) NSInteger optimal;
@property (nonatomic, assign) NSInteger pubStat;
@property (nonatomic, assign) NSInteger roomId;

@property (nonatomic, assign) NSInteger rotate;
@property (nonatomic, assign) NSInteger slot;

@property (nonatomic, assign) NSInteger status;
@property (nonatomic, assign) NSInteger version;

@property (nonatomic, copy) NSString *distance;

@property (nonatomic, getter=isShow) BOOL show;

@end
