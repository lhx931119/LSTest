//
//  LSAdvertise.m
//  LSTest
//
//  Created by 李宏鑫 on 16/12/1.
//  Copyright © 2016年 hongxinli. All rights reserved.
//

#import "LSAdvertise.h"

@implementation LSAdvertise

@end
