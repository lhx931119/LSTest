//
//  LSAdvertise.h
//  LSTest
//
//  Created by 李宏鑫 on 16/12/1.
//  Copyright © 2016年 hongxinli. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LSAdvertise : NSObject

@property (nonatomic, strong) NSString *image;
@property (nonatomic, strong) NSString *action;
@property (nonatomic, strong) NSString *link;
@property (nonatomic, assign) NSInteger position;

@end
