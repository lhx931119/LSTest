//
//  LSLive.m
//  LSTest
//
//  Created by 李宏鑫 on 16/11/29.
//  Copyright © 2016年 hongxinli. All rights reserved.
//

#import "LSLive.h"

@implementation LSLive

@end
