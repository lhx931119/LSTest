//
//  LSLiveChatViewController.m
//  LSTest
//
//  Created by 李宏鑫 on 16/11/30.
//  Copyright © 2016年 hongxinli. All rights reserved.
//

#import "LSLiveChatViewController.h"

@interface LSLiveChatViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *icnView;
@property (weak, nonatomic) IBOutlet UILabel *peopleCount;

@end

@implementation LSLiveChatViewController

- (void)setLive:(LSLive *)live
{

    _live = live;
    
    [self.icnView downloadImage:[NSString stringWithFormat:@"%@%@", IMAGE_HOST, live.creator.portrait] placeholder:@""];
    
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.icnView.layer.cornerRadius = 15;
    self.icnView.layer.masksToBounds = YES;
    
    
    [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(changePeopleCount) userInfo:nil repeats:YES];
    
    // Do any additional setup after loading the view from its nib.
}

- (void)changePeopleCount{

    self.peopleCount.text = [@(arc4random_uniform(10000)) description];
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
