//
//  LSMainViewController.m
//  LSTest
//
//  Created by 李宏鑫 on 16/11/28.
//  Copyright © 2016年 hongxinli. All rights reserved.
//

#import "LSMainViewController.h"
#import "LSMainTopView.h"

#import "LSLocationManger.h"

@interface LSMainViewController ()<UIScrollViewDelegate>
@property (weak, nonatomic) IBOutlet UIScrollView *contentScrollerView;

@property (nonatomic, strong) NSArray *dataSource;


@property (nonatomic, strong) LSMainTopView *topView;
@end

@implementation LSMainViewController


- (NSArray *)dataSource
{
    if (!_dataSource) {
        _dataSource = @[@"关注",@"热门",@"附近"];
    }
    return _dataSource;
}


- (LSMainTopView *)topView
{

    if (!_topView) {
        _topView = [[LSMainTopView alloc] initWithFrame:CGRectMake(0, 0, 200, 50) titlesNames:self.dataSource];
        
        __weak typeof(self) weakSelf = self;
        _topView.block = ^(NSInteger tag){
        
            CGPoint point = CGPointMake(tag * SCREEN_WIDTH, weakSelf.contentScrollerView.contentOffset.y);
            [weakSelf.contentScrollerView setContentOffset:point animated:YES];
        };
    }
    return _topView;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    [[LSLocationManger sharedManger] getGps:^(NSString *lat, NSString *lon) {
                
    }];

   

    [self setUI];
    // Do any additional setup after loading the view from its nib.
}


- (void)setUI{

    //添加左右按钮
    [self setNav];
    
    //添加子控制器
    [self setChildViewControllers];
    
}


- (void)setChildViewControllers{
    
    NSArray *vcNames = @[@"LSFocuseViewController",@"LSHotViewController",@"LSNearViewController"];
    for (int i = 0; i < vcNames.count; i++) {
        NSString *vcName = vcNames[i];
        UIViewController *vc = [[NSClassFromString(vcName) alloc] init];
        vc.title = self.dataSource[i];
        
        //执行 addChildViewController 不会执行vc的 didLoadView
        [self addChildViewController:vc];
    }
    
    //将子控制器的View添加到MainView的scrollerView
    //设置scrollerView的contensize
    self.contentScrollerView.contentSize = CGSizeMake(SCREEN_WIDTH * self.dataSource.count, 0);
    
    
    //默认加载第二页
    
    self.contentScrollerView.contentOffset = CGPointMake(SCREEN_WIDTH, 0);
    
    
    //进入控制器加载第一个页面
    [self scrollViewDidEndDecelerating:self.contentScrollerView];
}


- (void)setNav
{
    
    self.navigationItem.titleView = self.topView;
    
     
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"point_gray.png"] style:UIBarButtonItemStyleDone target:nil action:nil];
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"memberempty@2x.png"] style:UIBarButtonItemStyleDone target:nil action:nil];


}


//动画结束调用代理
- (void)scrollViewDidEndScrollingAnimation:(UIScrollView *)scrollView
{
    
    NSLog(@"%@", @(scrollView.contentOffset.x));
    CGFloat width = SCREEN_WIDTH;
    
    CGFloat height = SCREEN_HEIGHT;
    
    CGFloat offset = scrollView.contentOffset.x;
    //获取index
    NSInteger index = offset / width;
    
    //根据索引改变topView
    [self.topView scroller:index];
    
    
    //根据index返回vc控制器
    UIViewController *vc = self.childViewControllers[index];
    
    
    //判断当前vc是否执行过viewDidLoad
    
    if ([vc isViewLoaded]) {
        return;
    }
    //设置子控制器view的frame
    vc.view.frame = CGRectMake(offset, 0, width, height);
    
    //将子控制器的view添加到scrollView
    [scrollView addSubview:vc.view];

}

//减速结束时调用加载子控制器View的方法
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    
    [self scrollViewDidEndScrollingAnimation:scrollView];
    
}// called when scroll view grinds to a halt

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
