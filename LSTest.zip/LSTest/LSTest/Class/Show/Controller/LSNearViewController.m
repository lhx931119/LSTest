

//
//  LSNearViewController.m
//  LSTest
//
//  Created by 李宏鑫 on 16/11/28.
//  Copyright © 2016年 hongxinli. All rights reserved.
//

#import "LSNearViewController.h"

#import "LSLiveHandle.h"

#import "LSNearCell.h"

#import "LSLive.h"
#import "LSPlayerViewController.h"

#define LSMaign 5
#define LSItem 100

static NSString *identifier = @"LSNearCell";

@interface LSNearViewController ()<UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout>
@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;

@property (nonatomic, strong) NSMutableArray *datalist;

@end

@implementation LSNearViewController


- (void)collectionView:(UICollectionView *)collectionView willDisplayCell:(UICollectionViewCell *)cell forItemAtIndexPath:(NSIndexPath *)indexPath{

    LSNearCell *nearCell = (LSNearCell *)cell;
    [nearCell showAnimation];
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{

    [collectionView deselectItemAtIndexPath:indexPath animated:YES];
    
    LSLive *live = self.datalist[indexPath.row];
    
    LSPlayerViewController *playerVC = [[LSPlayerViewController alloc] init];
    playerVC.url = live.streamAddr;
    
    playerVC.live = live;
    
    [self.navigationController pushViewController:playerVC animated:YES];

}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{

    NSInteger count = self.collectionView.width / LSItem;
    CGFloat width = (self.collectionView.width - LSMaign * (count + 1)) / count;
    return CGSizeMake(width, width + 20);
}


- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{

    return self.datalist.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    LSNearCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:identifier forIndexPath:indexPath];
    cell.live = self.datalist[indexPath.row];
    return cell;
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    [self setUpUI];
    
    [self loadData];
    
    // Do any additional setup after loading the view from its nib.
}

- (void)setUpUI{

    [self.collectionView registerNib:[UINib nibWithNibName:@"LSNearCell" bundle:nil] forCellWithReuseIdentifier:identifier];
}


- (void)loadData{

    [LSLiveHandle executeGetNearLiveTaskWithSuccess:^(id obj) {
        
        self.datalist = [NSMutableArray arrayWithArray:obj];
        [self.collectionView reloadData];
        
    } failure:^(NSError *error) {
        
        
    }];

}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
