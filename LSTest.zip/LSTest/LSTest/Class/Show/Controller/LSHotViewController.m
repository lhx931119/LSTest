//
//  LSHotViewController.m
//  LSTest
//
//  Created by 李宏鑫 on 16/11/28.
//  Copyright © 2016年 hongxinli. All rights reserved.
//

#import "LSHotViewController.h"
#import "LSLiveHandle.h"
#import "LSLiveCell.h"
#import "LSPlayerViewController.h"

#import <MediaPlayer/MediaPlayer.h>

static NSString *identifier = @"LSLiveCell";

@interface LSHotViewController ()

@property (nonatomic, strong) NSMutableArray *dataSource;
@end

@implementation LSHotViewController




- (NSMutableArray *)dataSource
{
    if (!_dataSource) {
        _dataSource = [NSMutableArray array];
    }
    return _dataSource;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setUI];
    
    [self loadData];
    // Do any additional setup after loading the view from its nib.
}

- (void)setUI{

    
    [self.tableView registerNib:[UINib nibWithNibName:@"LSLiveCell" bundle:nil] forCellReuseIdentifier:identifier];
}

- (void)loadData{

    [LSLiveHandle executeGetHotLiveTaskWithSuccess:^(id obj) {
       
        [self.dataSource addObjectsFromArray:obj];
        [self.tableView reloadData];
        
           } failure:^(NSError *error) {
        
    }];
}


//tableView   delegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataSource.count;
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    LSLiveCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    cell.live = self.dataSource[indexPath.row];
    return cell;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 70 + SCREEN_WIDTH;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{

    [tableView deselectRowAtIndexPath:indexPath animated:YES];
     LSLive *live = self.dataSource[indexPath.row];
    
    LSPlayerViewController *playerVC = [[LSPlayerViewController alloc] init];
    playerVC.url = live.streamAddr;
    
    playerVC.live = live;
    
    [self.navigationController pushViewController:playerVC animated:YES];
    
    
    //系统自带的播放器无法播放直播内容
//    MPMoviePlayerViewController *movVc = [[MPMoviePlayerViewController alloc] initWithContentURL:[NSURL URLWithString:live.streamAddr]];
//    [self presentViewController:movVc animated:YES completion:nil];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
