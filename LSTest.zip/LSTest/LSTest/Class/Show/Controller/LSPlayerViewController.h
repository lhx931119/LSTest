//
//  LSPlayerViewController.h
//  LSTest
//
//  Created by 李宏鑫 on 16/11/30.
//  Copyright © 2016年 hongxinli. All rights reserved.
//

#import "LSBaseViewController.h"
#import "LSLive.h"

@interface LSPlayerViewController : LSBaseViewController

@property (nonatomic, strong) LSLive *live;

@property (nonatomic, strong) NSString *url;

@end
