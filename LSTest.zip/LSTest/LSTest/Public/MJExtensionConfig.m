//
//  MJExtensionConfig.m
//  LSTest
//
//  Created by 李宏鑫 on 16/11/29.
//  Copyright © 2016年 hongxinli. All rights reserved.
//

#import "MJExtensionConfig.h"
#import "LSCreator.h"
#import "LSLive.h"

@implementation MJExtensionConfig


+ (void)load
{
    
    
    [LSCreator mj_setupReplacedKeyFromPropertyName:^NSDictionary *{
        return @{@"ID":@"id"};
    }];
    
    [LSCreator mj_setupReplacedKeyFromPropertyName:^NSDictionary *{
        return @{@"desc":@"description"};
    }];

    
    //驼峰转下划线
    [LSCreator mj_setupReplacedKeyFromPropertyName121:^id(NSString *propertyName) {
        return [propertyName mj_underlineFromCamel];
    }];

    [LSLive mj_setupReplacedKeyFromPropertyName121:^id(NSString *propertyName) {
        return [propertyName mj_underlineFromCamel];
    }];

    
}
@end
