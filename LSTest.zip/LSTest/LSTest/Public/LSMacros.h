//
//  LSMacros.h
//  LSTest
//
//  Created by 李宏鑫 on 16/11/28.
//  Copyright © 2016年 hongxinli. All rights reserved.
//

#ifndef LSMacros_h
#define LSMacros_h


#define RGB(x,y,z)     [UIColor colorWithRed:(x/255.0) green:(y/255.0) blue:(z/255.0) alpha:1]

#define RGBA(x,y,z,a)     [UIColor colorWithRed:(x/255.0) green:(y/255.0) blue:(z/255.0) alpha:(a)]


#define SCREEN_WIDTH     [UIScreen mainScreen].bounds.size.width
#define SCREEN_HEIGHT    [UIScreen mainScreen].bounds.size.height

#define ADVERTISE_IMAGE  @"imageUrl"

#define PICTURE_PATH(A,B) [NSString stringWithFormat:@"%@%@",(A), (B)]

#define UserDefaultWrite(key,value)                [[NSUserDefaults standardUserDefaults] setObject:value forKey:key];

#define UserDefaultRead(key)                     [[NSUserDefaults standardUserDefaults] objectForKey:key]

#define UserDefaultRemove(key)                   [[NSUserDefaults standardUserDefaults] removeObjectForKey:key];

#define UserDefaultSynchronize        [[NSUserDefaults standardUserDefaults] synchronize];

#endif /* LSMacros_h */
